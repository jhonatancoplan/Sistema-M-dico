
package com.mycompany.sistema_hospitalar;

import java.sql.SQLException;

/**
 *
 * @author Aluno
 */
public class Sistema_hospitalar {

    public static void main(String[] args) throws SQLException {
    DatabaseSetup.inicializarBanco();
    new Entrar().setVisible(true); // ou a sua tela inicial
}

    }
