package com.mycompany.sistema_hospitalar;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class DatabaseSetup {

    private static final String URL = "jdbc:mysql://localhost:3306/hospital";
    private static final String USER = "root";
    private static final String PASSWORD = "mysql"; // <-- SENHA CORRETA DO AMPPS

    public static void inicializarBanco() {
        try {
            System.out.println("Tentando conectar ao MySQL...");

            // 1 — Conectar no MySQL sem selecionar banco
            Connection con = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Conexão com MySQL OK!");

            Statement stmt = con.createStatement();

            // 2 — Criar o banco de dados
            stmt.executeUpdate("CREATE DATABASE IF NOT EXISTS hospital");
            System.out.println("Banco 'hospital' verificado/criado.");

            // 3 — Conectar ao banco hospital
            con = DriverManager.getConnection(URL + "hospital", USER, PASSWORD);
         
            // 4 — Criar tabela Pacientes
            stmt.executeUpdate(
                "CREATE TABLE IF NOT EXISTS pacientes (" +
                "id INT AUTO_INCREMENT PRIMARY KEY," +
                "nome VARCHAR(100)," +
                "cpf VARCHAR(20)," +
                "idade INT," +
                "sexo VARCHAR(10)," +
                "endereco VARCHAR(200)" +
                "data_agendamento VARCHAR(20)," +
                "hora VARCHAR(10)" + 
                ")"
            );

            // 5 — Criar tabela Médicos
            stmt.executeUpdate(
                "CREATE TABLE IF NOT EXISTS medicos (" +
                "id INT AUTO_INCREMENT PRIMARY KEY," +
                "nome VARCHAR(100)," +
                "crm VARCHAR(50)," +
                "especialidade VARCHAR(100)" +
                ")"
            );
            stmt.executeUpdate(
                "CREATE TABLE Pesquisar_paciente_do_dia (" +
                "id INT AUTO_INCREMENT PRIMARY KEY," +
                "nome VARCHAR(100)," +
                "cpf VARCHAR(20)," +
                "data_atendimento DATE," +
                "horario TIME," +
                "sentindo TEXT," +
                "diagnostico TEXT," +
                "resolucao TEXT," +
                "arquivo VARCHAR(255)," +
                "tag VARCHAR(50)" +
                ")"
               );
            
            stmt.executeUpdate(
                "CREATE TABLE Pesquisar_ historico_do_paciente (" +
                "id INT AUTO_INCREMENT PRIMARY KEY," +
                "nome VARCHAR(100)," +
                "cpf VARCHAR(20)," +
                "data_atendimento DATE," +
                "horario TIME," +
                "sentindo TEXT," +
                "diagnostico TEXT," +
                "resolucao TEXT," +
                "arquivo VARCHAR(255)," +
                "tag VARCHAR(50)" +
                ")"
               );

            // 6 — Criar tabela Consultas
            stmt.executeUpdate(
                "CREATE TABLE IF NOT EXISTS consultas (" +
                "id INT AUTO_INCREMENT PRIMARY KEY," +
                "paciente_id INT," +
                "medico_id INT," +
                "data VARCHAR(20)," +
                "hora VARCHAR(20)," +
                "FOREIGN KEY (paciente_id) REFERENCES pacientes(id)," +
                "FOREIGN KEY (medico_id) REFERENCES medicos(id)" +
                ")"
            );

            System.out.println("Todas as tabelas foram criadas com sucesso!");

        } catch (Exception e) {
            System.out.println("Erro ao conectar ou criar banco!");
            e.printStackTrace();
        }
    }
}
